<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, "initial-scale=1.0">[20D[K
"initial-scale=1.0">
    <title>IP 查询工具</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            border-radius: 12px;
            background-color: white;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #2c3e50;
        }
        
        .input-section {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
            margin-bottom: 1.8rem;
        }
        
        input {
            width: 300px;
            padding: 12px 16px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        input:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        button:hover {
            background-color: #2980b9;
        }
        
        .result-section {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 24px;
        }
        
        .card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }
        
        .card h3 {
            margin-bottom: 14px;
            color: #2c3e50;
            font-size: 18px;
            border-bottom: 1px solid #eee;
            padding-bottom: 8px;
        }
        
        .card p {
            margin-bottom: 10px;
        }
        
        .highlight {
            font-weight: bold;
            color: #3498db;
        }
        
        .loading {
            text-align: center;
            margin: 2rem 0;
            display: none;
        }
        
        .error-message {
            background-color: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            display: none;
        }
        
        @media (max-width: 600px) {
            .input-section input {
                width: 240px;
            }
            
            body {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>IP 查询工具</h1>
        
        <div class="input-section">
            <input type="text" id="ip-input" placeholder="输入IP地址（可选）[K
" />
            <button id="query-btn">查询</button>
        </div>
        
        <div class="loading" id="loading">
            正在获取数据，请稍候...
        </div>
        
        <div class="error-message" id="error-message">
            无法连接到IP服务，可能是网络问题或API限制。
        </div>
        
        <div class="result-section">
            <!-- 结果将通过JavaScript动态生成 -->
        </div>
    </div>

    <script>
        const ipInput = document.getElementById('ip-input');
        const queryBtn = document.getElementById('query-btn');
        const resultSection = document.querySelector('.result-section');
        const loadingElement = document.getElementById('loading');
        const errorMessageElement = document.getElementById('error-message'[39D[K
document.getElementById('error-message');

        // 使用免费IP API获取数据
        async function getIpData(ip) {
            try {
                // 如果用户输入了IP地址，使用该IP；否则自动检测
                let url;
                
                if (ip && ip.trim() !== '') {
                    url = `https://api.ipify.org?ip=${encodeURIComponent(ip[49D[K
`https://api.ipify.org?ip=${encodeURIComponent(ip)}&format=json`;
                } else {
                    // 自动获取IP和位置信息
                    url = 'https://api.ipify.org?format=json';
                }
                
                loadingElement.style.display = 'block';
                errorMessageElement.style.display = 'none';
                
                const response = await fetch(url);
                const data = await response.json();
                
                // 使用ipapi.co获取更详细的地理位置信息
                let locationData;
                if (ip && ip.trim() !== '') {
                    url = `https://ipapi.co/${data.ip}/?format=json`;
                    response = await fetch(url);
                    locationData = await response.json();
                } else {
                    url = 'https://ipapi.co/json/';
                    response = await fetch(url);
                    locationData = await response.json();
                }
                
                return { ...data, ...locationData };
            } catch (error) {
                console.error('获取IP信息时出错:', error);
                errorMessageElement.textContent = '无法连接到IP服务，请稍后[K
再试。';
                errorMessageElement.style.display = 'block';
                loadingElement.style.display = 'none';
                resultSection.innerHTML = '';
                
                // 提供默认数据以防查询失败
                if (!ip) {
                    return { ip: '', city: '', region: '', country_name: ''[2D[K
'' };
                }
            }
        }

        async function displayIpData(data) {
            // 清空结果区域并添加新卡片
            resultSection.innerHTML = '';
            
            const ipAddressCard = createCard('IP 地址', data.ip);
            resultSection.appendChild(ipAddressCard);
            
            if (data.hostname && ipInput.value.trim() !== '') {
                const hostNameCard = createCard('主机名', data.hostname);
                resultSection.appendChild(hostNameCard);
            }
            
            // 根据是否有ipapi数据创建地理位置卡片
            let countryCard, cityCard, regionCard;
            if (data.country_name && typeof(data.country_name) === 'string'[8D[K
'string') {
                countryCard = createCard('国家/地区', data.country_name);
                resultSection.appendChild(countryCard);
                
                const countryCode = data.country_code ? `(${data.country_co[19D[K
`(${data.country_code})` : '';
                const ispCard = createCard('ISP提供商', `${data.org || '-'}[4D[K
'-'}`);
            }
            
        }

        function createCard(title, content) {
            const cardDiv = document.createElement('div');
            cardDiv.className = 'card';
            
            const titleElement = document.createElement('h3');
            titleElement.textContent = title;
            
            const contentElement = document.createElement('p');
            if (typeof(content) === 'string') {
                contentElement.innerHTML = `<span class="highlight">${conte[25D[K
class="highlight">${content}</span>`;
            } else if (Array.isArray(content)) {
                contentElement.textContent = content.join(', ');
            } else {
                contentElement.textContent = String(content);
            }
            
            cardDiv.appendChild(titleElement);
            cardDiv.appendChild(contentElement);
            return cardDiv;
        }

        // 点击查询按钮的事件处理
        queryBtn.addEventListener('click', async () => {
            const userIp = ipInput.value.trim();
            loadingElement.style.display = 'block';
            
            try {
                const data = await getIpData(userIp);
                
                if (data.ip) {
                    displayIpData(data);
                } else {
                    // 如果没有IP数据，显示错误信息
                    errorMessageElement.textContent = '未获取到有效IP地址，[K
请稍后再试。';
                    errorMessageElement.style.display = 'block';
                }
            } finally {
                loadingElement.style.display = 'none';
            }
        });

        // 页面加载时自动检测并显示IP信息
        document.addEventListener('DOMContentLoaded', async () => {
            const data = await getIpData('');
            if (data.ip) {
                displayIpData(data);
            }
        });
    </script>
</body>
</html>
